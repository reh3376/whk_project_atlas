# Work log

Use this as a daily/weekly journal of what happened.

## Format
### YYYY-MM-DD
- What I did:
- What I learned:
- What changed:
- What I will do next:

---

## Sprint summaries
At the end of each sprint, add:
- Sprint goal
- Deliverables shipped
- Key decisions (ADR links)
- What to improve next sprint
