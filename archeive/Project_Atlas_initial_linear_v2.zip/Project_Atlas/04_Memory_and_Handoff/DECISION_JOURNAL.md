# Decision journal

This is a lightweight index of decisions. The full details belong in ADRs.

## Format
- Date:
- Decision:
- Why:
- Evidence:
- Where implemented:
- ADR link:

---

## Decisions
- (Add entries here)
