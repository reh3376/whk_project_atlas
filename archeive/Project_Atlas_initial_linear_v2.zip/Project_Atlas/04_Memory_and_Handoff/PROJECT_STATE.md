# Project state (single source of truth)

_Last updated: 2025-12-14_

## Current focus
- Phase: Phase 00 — Foundation Setup
- Sprint: Sprint 00.1
- Objective this week: (fill in)

## What was completed since last update
- 

## Next 3 tasks (do these next)
1. 
2. 
3. 

## Decisions made since last update
- (Link ADRs and decision journal entries)

## Metrics snapshot (optional but recommended)
- Lead time:
- Deployment frequency:
- Change failure rate:
- MTTR:

## Key links
- Roadmap: ../01_Roadmap/roadmap.md
- Phase map: ../01_Roadmap/phase_map.md
- Current phase Start Here: ../Phases/Phase_00_Foundation_Setup/Start_Here.md
- Linear integration notes: ../05_Toolchain_Integrations/Linear/README.md

## Linear Links (sync layer)

> Rule: `PROJECT_STATE.md` is canonical status; Linear is canonical execution. Keep these links current.

- Initiative (Project Atlas): 
- Project (P00 — Foundation Setup): 
- Project (P01 — Modular Platform Architecture): 
- Project (P02 — SDLC & DevEx Standardization): 
- Project (P03 — Data Pipeline & Curated Datasets): 
- Project (P04 — MLOps + SME Supervision): 
- Project (P05 — Reliability / Observability / Security): 

## GitHub Links (optional)
- Repo root:
- Default branch:
- PRs (filtered):
