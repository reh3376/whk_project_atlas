# Context packet (copy/paste into a new AI chat)

> This file is designed to be pasted into a chat assistant to restore context.
> Regenerate it with `python Tools/make_context_packet.py` whenever you want it fresh.

## 1) Project intent (high level)

Project Atlas is a long-term program to build frameworks and roadmaps for:
- Modular backend platforms (core + modules/plugins)
- Curated data pipelines (metadata + lineage + periodic snapshots for ML)
- SME-supervised narrow AI orchestration for ML-heavy process optimization tools

Primary output mode: architectural leadership, supported by implementation and SDLC.

Execution tracking: Linear (projects per phase). Canonical status: `PROJECT_STATE.md`.

Tech stack:
- Backend: Python (Cython optional) + C libraries for compute-heavy code
- Frontend: Next.js / JS/TS
- Deployment: container-first, on-prem/intranet preferred

Evidence policy:
- Prefer peer-reviewed sources (Tier A)
- Standards/specs allowed but labeled (Tier B)
- Vendor docs labeled (Tier C)
- Blogs require warning (Tier D)

## 2) Current state
(See `04_Memory_and_Handoff/PROJECT_STATE.md` and paste key lines here.)

## 3) What I want from the assistant in this session
- 

## 4) Non-negotiables
- Output must produce tangible deliverables (docs/code/checklists).
- No un-cited claims presented as fact; label non-peer-reviewed material.

## 5) Where the files are
- Roadmap: `01_Roadmap/`
- Templates: `02_Templates/`
- Phase work: `Phases/`
- Handoff/memory: `04_Memory_and_Handoff/`
