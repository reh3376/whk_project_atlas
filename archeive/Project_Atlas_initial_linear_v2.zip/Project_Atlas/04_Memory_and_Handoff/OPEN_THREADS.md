# Open threads

Questions and uncertainties that should not be forgotten.

## Format
- Question / unknown:
- Why it matters:
- Possible approaches:
- Owner:
- Due (optional):

---

## Open items
- 
