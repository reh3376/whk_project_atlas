# Runbook

## Purpose
## Preconditions
## Step-by-step
1.
2.
3.

## Verification
How to confirm success.

## Rollback
How to revert safely.

## Escalation
Who to contact and when.

## References
