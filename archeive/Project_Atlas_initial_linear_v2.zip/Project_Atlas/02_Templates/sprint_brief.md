# Sprint brief

## Sprint ID
- Phase:
- Sprint:
- Dates:
- Owner(s):

## Goal (1–2 sentences)

## Why this matters (first principles)

## Scope
In:
- 
Out:
- 

## Inputs
- Primary sources (peer-reviewed preferred):
  - 
- Constraints:
  - 

## Deliverables (must be tangible)
- [ ] Design doc:
- [ ] ADRs:
- [ ] Prototype / code:
- [ ] Checklist / runbook:
- [ ] Retro:

## Acceptance criteria
- Measurable criteria (latency, correctness, reproducibility, etc.)
- “Done means done” definition

## Risks & unknowns
- 
## Work plan (high level)
- Week 1:
- Week 2:
