# Experiment log

## Hypothesis
## Setup
- Code/version:
- Environment:
- Inputs:

## Metrics
- 

## Results
- 

## Interpretation
- What does this suggest?
- What would falsify this?
- Next experiment:
