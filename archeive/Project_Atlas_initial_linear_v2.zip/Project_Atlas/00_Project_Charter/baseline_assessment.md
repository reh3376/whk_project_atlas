# Baseline assessment

Purpose: capture your starting point so improvements are measurable.

## Quick self-assessment (0–3)

Rate each:
- Architecture tradeoffs (boundaries, coupling, change tolerance)
- SDLC design (CI/CD, testing strategy, release patterns)
- Distributed systems fundamentals
- Observability (logs/metrics/traces)
- Reliability/SRE (SLOs, incident response)
- Security fundamentals (threat modeling, authn/authz)
- Data engineering (schemas, lineage, idempotency)
- MLOps (evaluation, drift, monitoring)
- Team process leadership (cadence, alignment, adoption)

## Objective exercises (recommended)

- Write a design doc for a modular platform core + plugin system.
- Implement a minimal plugin loader and versioned interface in Python.
- Implement a small C library callable from Python for a compute-heavy function.
- Build a “toy” pipeline that snapshots curated data with lineage metadata.
- Produce an SLO and a load test for a simple API.

Record results and links here.
