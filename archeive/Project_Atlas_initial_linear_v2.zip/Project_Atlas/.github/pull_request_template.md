## Linear

- Linear Issue: <!-- paste URL or ID (e.g., ATLAS-123) -->

## Summary

- What changed and why?

## Test plan

- [ ] Unit tests
- [ ] Integration tests
- [ ] Manual verification
- Notes:

## Risk & rollback

- Risk level: low / medium / high
- Rollback plan:

## Docs / artifacts updated

- [ ] PROJECT_STATE.md (if this affects next steps)
- [ ] Design doc / ADR (if this is an architectural change)
- [ ] Runbook (if operational impact)
