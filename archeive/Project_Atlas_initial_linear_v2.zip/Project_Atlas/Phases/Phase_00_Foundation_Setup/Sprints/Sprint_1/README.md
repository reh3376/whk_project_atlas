# Sprint 1 (placeholder)

Copy `02_Templates/sprint_brief.md` into this folder and fill it out.

Suggested deliverables:
- 1 design doc
- 2–5 ADRs
- a runnable prototype
- a checklist/runbook
- sprint retro
